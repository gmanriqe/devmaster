<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Usando Formularios</h1>
    <form name="formulario" method="POST" action="ejercicio04-logic.php" >
        <label for="">Numero 1:</label><br>
        <input type="text" name="number_1"><br>
        <label for="">Numero 2:</label><br>
        <input type="text" name="number_2"><br>
        <label for="">Numero 3:</label><br>
        <input type="text" name="number_3"><br>
        <input type="submit" value="Enviar">
    </form>
</body>
</html>