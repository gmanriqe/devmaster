<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ejercicio 01 - Tabla Multiplicar</title>
</head>
<body>
    <h1>Tabla de multiplicar de un Número</h1>
    <form name="formulario" method="POST" action="ejercicio01-logic.php">
        <label for="number">Numero:</label><br>
        <input type="text" id="number" name="number"><br>
        <input type="submit" value="Visualizar Tabla">
    </form>
</body>
</html>